package com.demo.convertor.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.convertor.dto.HtmlToPdfRequest;
import com.demo.convertor.dto.JsonToFileRequest;
import com.demo.convertor.service.ConversionService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/convert")
@RequiredArgsConstructor
public class ConversionController {

    private final ConversionService conversionService;

    @PostMapping("/json-to-file")
    public ResponseEntity<byte[]> convertJsonToFile(@RequestBody JsonToFileRequest request) {
        byte[] fileContent;
        String fileName;
        MediaType mediaType;

        if ("csv".equalsIgnoreCase(request.getFormat())) {
            fileContent = conversionService.convertJsonToCsv(request);
            fileName = "output.csv";
            mediaType = MediaType.parseMediaType("text/csv");
        } else {
            fileContent = conversionService.convertJsonToExcel(request);
            fileName = "output.xlsx";
            mediaType = MediaType.APPLICATION_OCTET_STREAM;
        }

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName)
                .contentType(mediaType)
                .body(fileContent);
    }

    @PostMapping("/html-to-pdf")
    public ResponseEntity<byte[]> convertHtmlToPdf(@RequestBody HtmlToPdfRequest request) {
        byte[] pdfFile = conversionService.convertHtmlToPdf(request);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=output.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdfFile);
    }
}
