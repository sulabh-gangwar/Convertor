package com.demo.convertor.service;

import com.demo.convertor.dto.HtmlToPdfRequest;
import com.demo.convertor.dto.JsonToFileRequest;
import com.demo.convertor.entity.Template;
import com.itextpdf.html2pdf.HtmlConverter;

import lombok.RequiredArgsConstructor;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ConversionService {

    private final TemplateService templateService;

    public byte[] convertJsonToExcel(JsonToFileRequest request) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Data");

            // Create header row
            Row headerRow = sheet.createRow(0);
            for (int i = 0; i < request.getColumns().size(); i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(request.getColumns().get(i));
            }

            // Create data rows
            int rowNum = 1;
            for (Map<String, Object> rowData : request.getData()) {
                Row row = sheet.createRow(rowNum++);
                for (int i = 0; i < request.getColumns().size(); i++) {
                    Cell cell = row.createCell(i);
                    Object value = rowData.get(request.getColumns().get(i));
                    if (value != null) {
                        cell.setCellValue(value.toString());
                    }
                }
            }

            // Auto-size columns
            for (int i = 0; i < request.getColumns().size(); i++) {
                sheet.autoSizeColumn(i);
            }

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return outputStream.toByteArray();
        } catch (IOException e) {
            throw new RuntimeException("Failed to create Excel file", e);
        }
    }

    public byte[] convertJsonToCsv(JsonToFileRequest request) {
        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                PrintWriter writer = new PrintWriter(outputStream)) {

            // Write header
            String header = request.getColumns().stream()
                    .map(this::escapeCsvField)
                    .collect(Collectors.joining(","));
            writer.println(header);

            // Write data rows
            for (Map<String, Object> rowData : request.getData()) {
                String row = request.getColumns().stream()
                        .map(column -> escapeCsvField(String.valueOf(rowData.getOrDefault(column, ""))))
                        .collect(Collectors.joining(","));
                writer.println(row);
            }

            writer.flush();
            return outputStream.toByteArray();
        } catch (IOException e) {
            throw new RuntimeException("Failed to create CSV file", e);
        }
    }

    private String escapeCsvField(String field) {
        if (field == null) {
            return "";
        }
        // Escape quotes and wrap in quotes if the field contains comma or newline
        if (field.contains(",") || field.contains("\"") || field.contains("\n")) {
            return "\"" + field.replace("\"", "\"\"") + "\"";
        }
        return field;
    }

    public byte[] convertHtmlToPdf(HtmlToPdfRequest request) {
        try {
            Template template = templateService.getTemplate(request.getTemplateId());
            String htmlContent = template.getHtmlContent();

            // Replace placeholders with actual data
            htmlContent = replacePlaceholders(htmlContent, request.getData());

            if (template.getCssContent() != null && !template.getCssContent().isEmpty()) {
                htmlContent = "<style>" + template.getCssContent() + "</style>" + htmlContent;
            }

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            HtmlConverter.convertToPdf(htmlContent, outputStream);
            return outputStream.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Failed to create PDF file", e);
        }
    }

    private String replacePlaceholders(String template, Map<String, Object> data) {
        if (data == null)
            return template;

        String result = template;
        for (Map.Entry<String, Object> entry : data.entrySet()) {
            String placeholder = "\\{\\{" + Pattern.quote(entry.getKey()) + "\\}\\}";
            String value = entry.getValue() != null ? entry.getValue().toString() : "";
            result = result.replaceAll(placeholder, value);
        }
        return result;
    }

}
