package com.demo.convertor.dto;

import lombok.Data;

@Data
public class TemplateDto {
    private String name;
    private String htmlContent;
    private String cssContent;
}
