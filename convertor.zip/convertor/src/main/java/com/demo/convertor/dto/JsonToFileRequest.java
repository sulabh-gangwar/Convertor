package com.demo.convertor.dto;

import lombok.Data;
import java.util.List;
import java.util.Map;

@Data
public class JsonToFileRequest {
    private List<String> columns;
    private List<Map<String, Object>> data;
    private String format;
}
