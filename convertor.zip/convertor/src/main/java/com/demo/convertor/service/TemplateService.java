package com.demo.convertor.service;

import org.springframework.stereotype.Service;

import com.demo.convertor.dto.TemplateDto;
import com.demo.convertor.entity.Template;
import com.demo.convertor.repository.TemplateRepository;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TemplateService {

    private final TemplateRepository templateRepository;

    public Template createTemplate(TemplateDto templateDto) {
        Template template = new Template();
        template.setName(templateDto.getName());
        template.setHtmlContent(templateDto.getHtmlContent());
        template.setCssContent(templateDto.getCssContent());
        return templateRepository.save(template);
    }

    public Template getTemplate(Long id) {
        return templateRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Template not found with id: " + id));
    }

    public List<Template> getAllTemplates() {
        return templateRepository.findAll();
    }

    public Template updateTemplate(Long id, TemplateDto templateDto) {
        Template template = getTemplate(id);
        template.setName(templateDto.getName());
        template.setHtmlContent(templateDto.getHtmlContent());
        template.setCssContent(templateDto.getCssContent());
        return templateRepository.save(template);
    }

    public void deleteTemplate(Long id) {
        Template template = getTemplate(id);
        templateRepository.delete(template);
    }
}
