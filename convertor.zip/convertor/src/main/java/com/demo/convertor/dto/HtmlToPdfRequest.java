package com.demo.convertor.dto;

import java.util.Map;

import lombok.Data;

@Data
public class HtmlToPdfRequest {
    private Long templateId;
    private Map<String, Object> data;
}