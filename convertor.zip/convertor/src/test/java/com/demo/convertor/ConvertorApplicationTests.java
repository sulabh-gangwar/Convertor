package com.demo.convertor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConvertorApplicationTests {

	@Test
	void contextLoads() {
	}

}
